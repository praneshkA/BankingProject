/**
 * 
 */
/**
 * 
 */
module bankingappilication {
	requires java.sql;
}