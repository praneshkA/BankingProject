package banking;

public class bankingapp {
      public static void main(String[] args) {
    	  bank bank=new bank();
    	  bank.start();
      }
}
