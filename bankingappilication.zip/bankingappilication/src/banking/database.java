package banking;

import java.sql.*;

public class database {
    private Connection connection;

    // Constructor to establish the connection
    public database() {
        try {
            // Establish a connection to the MySQL database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "jai1466@1");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
